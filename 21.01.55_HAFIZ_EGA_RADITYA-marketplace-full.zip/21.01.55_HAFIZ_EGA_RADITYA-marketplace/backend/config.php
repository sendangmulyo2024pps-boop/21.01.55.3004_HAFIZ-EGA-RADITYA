<?php
// edit DB credentials
?>